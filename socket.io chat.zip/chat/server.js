const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session'); // Dodaj to
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);


const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const messagesContainer = document.getElementById('messages-container');

messageForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const messageText = messageInput.value;
    const username = 'Kuba'; // Replace with the logged-in user's username
    const message = {
      username,
      text: messageText,
    };

    await fetch('/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(message),
      });
    
      // Clear the message input
      messageInput.value = '';
    
      // Update the messages container
      const messageElement = document.createElement('p');
      messageElement.innerHTML = `<strong>${username}:</strong> ${messageText}`;
      messagesContainer.appendChild(messageElement);
    });



app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true })); // Dodaj to

let messages = [];
// Stałe loginy i hasła (na potrzeby testowe)
const users = [
    { username: 'Kuba', password: '123' },
    { username: 'Maks', password: '234' },
    { username: 'Wiktor', password: '345' },
    { username: 'Piotrek', password: '456' },
    { username: 'Patryk', password: '567' },
    { username: 'Karol', password: '678' }
];



app.post('/message', (req, res) => {
  const { username, text } = req.body;
  messages.push({ username, text });
  res.status(201).send();
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
  
    const user = users.find((user) => user.username === username && user.password === password);
  
    if (user) {
      res.status(200).json({ username: user.username });
    } else {
      res.status(401).send({ error: 'Invalid username or password' });
    }
  });

  app.get('/messages', (req, res) => {
    res.json(messages);
  });
  
  app.post('/message', (req, res) => {
    const { username, text } = req.body;
    messages.push({ username, text });
    res.status(201).send();
  });
  
  // Add a new endpoint to get the number of messages
  app.get('/message-count', (req, res) => {
    res.json({ count: messages.length });
  });
  



app.use(bodyParser.urlencoded({ extended: true })); // Dodaj to
app.use(bodyParser.json()); // Dodaj to

app.get('/chat', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'source','layout', 'login.html'));
});


app.use("/source", express.static(path.join(__dirname, '/source')))

// Socket.io connection
io.on('connection', (socket) => {
    console.log('New user connected');

    // Listen for chat messages
    socket.on('chatMessage', (message) => {
        io.emit('chatMessage', message);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});



