// Display the username
document.getElementById('username-display').innerHTML = `Welcome, ${username}!`;

const messagesContainer = document.getElementById('messages-container');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');

// Add event listener to the message form
messageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const messageText = messageInput.value;
    const message = {
        username,
        text: messageText,
    };

    // Send the message to the server
    fetch('/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(message),
    });

    // Clear the message input
    messageInput.value = '';
});

// Get messages from the server and display them
async function getMessages() {
    const response = await fetch('/messages');
    const messages = await response.json();
    messagesContainer.innerHTML = '';
    messages.forEach((message) => {
        const messageElement = document.createElement('p');
        messageElement.innerHTML = `<strong>${message.username}:</strong> ${message.text}`;
        messagesContainer.appendChild(messageElement);
    });
}

// Call the getMessages function periodically
setInterval(getMessages, 1000);

// Call the getMessages function initially
getMessages();